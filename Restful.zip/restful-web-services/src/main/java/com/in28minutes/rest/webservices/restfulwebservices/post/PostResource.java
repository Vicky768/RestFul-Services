package com.in28minutes.rest.webservices.restfulwebservices.post;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class PostResource {
	
	@Autowired
	private PostDaoService service;
	
	//retrieve all posts for User 
	
	@GetMapping("/users/{userId}/posts")
	public List<Post> retrievePostsByUsers(@PathVariable int userId)
	{
		return service.findPostsById(userId);
	}
	
	//retrieve posts by userid and post id 
	@GetMapping("/users/{userId}/posts/{postId}")
	public EntityModel<Post> retrieveAllDetailsOfPosts(@PathVariable int userId, @PathVariable int postId)
	{
		Post post = service.findPostByPostId(userId, postId);
		
		if(post==null)
			throw new PostNotFoundException("UserId"+userId+"PostId="+postId);
		
		//HATEOAS
		EntityModel<Post> resource = EntityModel.of(post);
		WebMvcLinkBuilder linkTo = 
				linkTo(methodOn(this.getClass()).retrievePostsByUsers(userId));
		resource.add(linkTo.withRel("all-posts-by-the-user"));
		
		return resource;
	}
	
	//retrieving the post counting 
	@GetMapping("/postCounter")
	public List<Counter> retrieveAllPostCounts()
	{
		return service.findPostCountersAll();
	}
	
	
	//creating a Post 
	@PostMapping("/users/{userId}/posts")
	public ResponseEntity<Object> createPost(@PathVariable int userId,@RequestBody Post post)
	{
		Post newPost = service.savePost(userId, post);
		
		//created status 
		
		URI location=ServletUriComponentsBuilder.
		fromCurrentRequest()
		.path("/{postId}")
		.buildAndExpand(post.getPostId())
		.toUri();
		
		return ResponseEntity.created(location).build();
	}
}
