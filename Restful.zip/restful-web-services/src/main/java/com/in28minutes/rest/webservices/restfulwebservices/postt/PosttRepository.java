package com.in28minutes.rest.webservices.restfulwebservices.postt;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PosttRepository extends JpaRepository<Postt,Integer>{

}
