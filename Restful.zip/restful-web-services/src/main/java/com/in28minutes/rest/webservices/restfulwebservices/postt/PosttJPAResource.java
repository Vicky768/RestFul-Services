package com.in28minutes.rest.webservices.restfulwebservices.postt;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.in28minutes.rest.webservices.restfulwebservices.post.PostNotFoundException;
import com.in28minutes.rest.webservices.restfulwebservices.user.User;
import com.in28minutes.rest.webservices.restfulwebservices.user.UserNotFoundException;
import com.in28minutes.rest.webservices.restfulwebservices.user.UserRepository;

@RestController
public class PosttJPAResource {
	
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private PosttRepository posttRepository;
	
	//retrieve all posts by a user
	@GetMapping("/jpa/users/{userId}/posts")
	public List<Postt> retrieveAllPostByUser(@PathVariable int userId)
	{
		Optional<User> user = userRepository.findById(userId);
		if(!user.isPresent())
			throw new UserNotFoundException("user Id-"+userId);
		
		return user.get().getPosts();
	}
	
	//get a definite posts 
	@GetMapping("/jpa/users/{userId}/posts/{postId}")
	public EntityModel<Postt> retrievePosttById(@PathVariable int userId, @PathVariable int postId)
	{
		Optional<Postt> posttOptional = posttRepository.findById(postId); //check if post id exists
		if(!posttOptional.isPresent())
			throw new PostNotFoundException("post - id ="+postId);
		
		Optional<User> userOptional = userRepository.findById(userId);   //check if user id exists
		if(!userOptional.isPresent())
			throw new UserNotFoundException("user - id="+userId);
		
		int user_postId = posttOptional.get().getUser().getUserId(); 
		
		//checking if the user has a post of given id
		if(user_postId!=userId)
			throw new PostNotFoundException("No such posts of id = "+postId+" could be found for user of "+userId);
		
		//HATEOS linking a link to get all posts of the given user.
		EntityModel<Postt> resource = EntityModel.of(posttOptional.get());
		WebMvcLinkBuilder linkTo = 
				WebMvcLinkBuilder.linkTo(methodOn(this.getClass()).retrieveAllPostByUser(userId));
		
		resource.add(linkTo.withRel("all-posts"));
		return resource;
	}
	
	
	//create a post 
	@PostMapping("/jpa/users/{userId}/posts")
	public ResponseEntity<Object> createPosts(@PathVariable int userId, @RequestBody Postt postt)
	{
		Optional<User> userOptional = userRepository.findById(userId);
		if(!userOptional.isPresent())
			throw new UserNotFoundException("user-id"+userId);
		
		User user= userOptional.get();
		
		postt.setUser(user);
		
		Postt savedPostt=posttRepository.save(postt);
		
		URI location = ServletUriComponentsBuilder
				.fromCurrentRequest()
				.path("/{postId}")
				.buildAndExpand(savedPostt.getId())
				.toUri();
		
		return ResponseEntity.created(location).build();
	}
}
