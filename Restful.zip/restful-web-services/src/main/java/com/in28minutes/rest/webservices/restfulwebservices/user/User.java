package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import com.in28minutes.rest.webservices.restfulwebservices.postt.Postt;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;


@ApiModel(description="Details about data provided by User")

@Entity
public class User {
	
	@Id
	@GeneratedValue
	private Integer userId;
	
	@ApiModelProperty(notes="Name should atleast have 2 characters")
	@Size(min=2, message="Name should have atleast 2 characters")     //setting the limit that size of name is greater than 2 
	private String name;
	
	@ApiModelProperty(notes="The birthdate cannot be in the present or future")
	@Past
	private Date birthDate;				//setting limitation that birthdate can in past 
	
	@OneToMany(mappedBy="user")
	private List<Postt> posts;
	

	protected User() {
		
	}
	
	public User(Integer userId, String name, Date birthDate) {
		super();
		this.userId = userId;
		this.name = name;
		this.birthDate = birthDate;
	}


	public Integer getUserId() {
		return userId;
	}


	public void setUserId(Integer userId) {
		this.userId = userId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Date getBirthDate() {
		return birthDate;
	}


	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	
	public List<Postt> getPosts() {
		return posts;
	}

	public void setPosts(List<Postt> posts) {
		this.posts = posts;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", name=" + name + ", birthDate=" + birthDate + "]";
	}
	
	
	
	
}
