package com.in28minutes.rest.webservices.restfulwebservices.post;

import java.util.Date;

import io.swagger.annotations.ApiModel;

@ApiModel(description="All details about the post")
public class Post {
	
	private Integer userId;
	private Integer postId;
	private String postMessage;
	private Date dateCreated;
	public Post(Integer userId, Integer postId, String postMessage, Date dateCreated) {
		super();
		this.userId = userId;
		this.postId = postId;
		this.postMessage = postMessage;
		this.dateCreated = dateCreated;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getPostId() {
		return postId;
	}
	public void setPostId(Integer postId) {
		this.postId = postId;
	}
	public String getPostMessage() {
		return postMessage;
	}
	public void setPostMessage(String postMessage) {
		this.postMessage = postMessage;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	@Override
	public String toString() {
		return "Post [userId=" + userId + ", postId=" + postId + ", postMessage=" + postMessage + ", dateCreated="
				+ dateCreated + "]";
	}
	
	
	
}
