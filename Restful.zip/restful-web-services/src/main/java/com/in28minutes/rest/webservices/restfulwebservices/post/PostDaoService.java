package com.in28minutes.rest.webservices.restfulwebservices.post;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Component;

import com.in28minutes.rest.webservices.restfulwebservices.user.User;

@Component
public class PostDaoService {
	
	private static List<Post> posts = new ArrayList<>();
	private static List<Counter> postCounters = new ArrayList<>();
	
	static {
		
		posts.add(new Post(1,1,"1st User First Post",new Date()));
		//postCounters.add(new Counter(1,1));
		
		posts.add(new Post(1,2,"1st User Second Post",new Date()));
		postCounters.add(new Counter(1,2));
		
		
		posts.add(new Post(2,1,"2nd User First Post",new Date()));
		//postCounters.add(new Counter(2,1));
		
		posts.add(new Post(2,2,"2nd user Second Post",new Date()));
		postCounters.add(new Counter(2,2));
	}
	
	//retrieve posts by a userId
	public List<Post> findPostsById(int userId)
	{
		List<Post> usersPost = new ArrayList<>();
		for(Post post:posts)
		{
			if(post.getUserId()==userId)
			{
				usersPost.add(post);
			}
		}
		return usersPost;	
	}
	
	//retrieve details of a post
	public Post findPostByPostId(int userId, int postId)
	{
		for(Post post:posts)
		{
			if(post.getUserId()==userId && post.getPostId()==postId)
				return post;
		}
		return null;
	}
	//display the Post Counters 
	public List<Counter> findPostCountersAll()
	{
		return postCounters;
	}
	//create a post for a user 
	public Post savePost(int userId,Post post)
	{
		int postId=0;
		for(Counter postCount:postCounters)
		{
			if(postCount.getUserId()==userId)        //checking if the user has a count record
			{
				postId=postCount.getPostId()+1;  
				//System.out.println("Post Id="+postId);
				postCount.setPostId(postId);//updating the count record
				
				post.setPostId(postId);
				
				posts.add(post);
				return post;
			}
		}
		postCounters.add(new Counter(userId,1));  //creating a new user record 
		postId=1; 
		
		post.setPostId(postId);
		
		posts.add(post);
		
		return post;
	}
}
