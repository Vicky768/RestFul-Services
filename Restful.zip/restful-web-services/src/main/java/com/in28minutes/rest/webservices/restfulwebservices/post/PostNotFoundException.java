package com.in28minutes.rest.webservices.restfulwebservices.post;


public class PostNotFoundException extends RuntimeException {

	private String message;
	
	public PostNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	
}
