insert into user values(1001,sysdate(),'AB');
insert into user values(1002,sysdate(),'Jack');
insert into user values(1003,sysdate(),'Jill');
insert into Postt values(1100,'First Post',1002);
insert into Postt values(1101,'Second Post',1002);
insert into Postt values(1102,'eScond Post',1001);