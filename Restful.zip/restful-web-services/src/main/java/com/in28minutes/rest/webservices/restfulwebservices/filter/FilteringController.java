package com.in28minutes.rest.webservices.restfulwebservices.filter;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;

@RestController
public class FilteringController {
		
	
		//for somebean it is static filtering 
		@GetMapping("/filtering")
		public SomeBean retrieveSomeBean()
		{
			return new SomeBean("value1","value2","value3");
		}
		
		@GetMapping("/filtering-list")
		public List<SomeBean> retrieveListofSomeBeans()
		{
			return Arrays.asList(new SomeBean("value1","value2","value3"),new SomeBean("value4","value5","value6"));
		}
		
		
		//for someotherbean , it is dynamic filtering 
		
		//in this method want to send field1 and field2 
		@GetMapping("/filtering2")
		public MappingJacksonValue retrieveSomeOtherBean()
		{
			SomeOtherBean someOtherBean = new SomeOtherBean("value1","value2","value3");
			//Dynamic Filtering
			
			SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter
					.filterOutAllExcept("field1","field2");
			FilterProvider filters=new SimpleFilterProvider().addFilter("SomeOtherBeanFilter",filter);
			MappingJacksonValue mapping = new MappingJacksonValue(someOtherBean);
			
			mapping.setFilters(filters);
			
			return mapping;
		}
		
		
		//in this , we send only field2 and field3 
		@GetMapping("/filtering-list2")
		public MappingJacksonValue retrieveListofSomeOtherBeans()
		{
			List<SomeOtherBean> asList = Arrays.asList
					(new SomeOtherBean("value1","value2","value3"),new SomeOtherBean("value4","value5","value6"));
			
			
			//Dynamic Filtering 
			SimpleBeanPropertyFilter filter = SimpleBeanPropertyFilter.filterOutAllExcept("field2","field3");
			FilterProvider filters = new SimpleFilterProvider().addFilter("SomeOtherBeanFilter", filter);
			MappingJacksonValue mapping = new MappingJacksonValue(asList);
			
			mapping.setFilters(filters);
			
			return mapping;
		}
}
