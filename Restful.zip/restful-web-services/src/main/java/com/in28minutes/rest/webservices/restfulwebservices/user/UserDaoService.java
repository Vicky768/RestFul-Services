package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class UserDaoService {
	
	private static List<User> users = new ArrayList<>();
	private static int userCount=4;
	
	static {
		users.add(new User(1,"Adam",new Date()));
		users.add(new User(2,"Eve",new Date()));
		users.add(new User(3,"Jack",new Date()));
		users.add(new User(4,"Ranga",new Date()));
	}
	
	//find User by Id
	
	public User findUserById(int userId)
	{
		for(User user:users)
		{
			if(user.getUserId()==userId)
			{
				return user;
			}
		}
		return null;
	}
	
	//find All Users 
	public List<User> findAllUsers()
	{
		return users;
	}
	
	//create a new User
	public User save(User user)
	{
		if(user.getUserId()==null)          //Integer variable can be checked with null but int cannot
											//be checked with null
		{
			userCount++;
			user.setUserId(userCount);
		}
		users.add(user);
		return user;
	}
	
	public User deleteById(int id)
	{
		Iterator<User> iterator = users.iterator();
		while(iterator.hasNext()) {
			User user = iterator.next();
			if(user.getUserId()==id) {
				iterator.remove();
				return user;
			}
		}
		return null;
	}
	
}
